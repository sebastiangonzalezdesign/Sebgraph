const s="/assets/cv-sebastian-gonzalez-BTb1jjXS.pdf";export{s as C};
