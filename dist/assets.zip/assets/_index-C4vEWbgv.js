const s="/assets/cv-sebastian-gonzalez-CEC9bqgx.pdf";export{s as C};
