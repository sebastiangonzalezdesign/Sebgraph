const s="/assets/cv-sebastian-gonzalez-d05a8bab.pdf";export{s as C};
