const a="/assets/cv-sebastian-gonzalez-d05a8bab.pdf";export{a as C};
