const s="/assets/cv-sebastian-gonzalez-610086c7.pdf";export{s as C};
