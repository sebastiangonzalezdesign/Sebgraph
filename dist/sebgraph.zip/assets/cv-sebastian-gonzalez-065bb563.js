const s="/assets/cv-sebastian-gonzalez-fd11542a.pdf";export{s as C};
